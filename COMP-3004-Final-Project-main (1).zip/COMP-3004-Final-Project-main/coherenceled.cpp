#include "coherenceled.h"

CoherenceLED::CoherenceLED()
{

}
