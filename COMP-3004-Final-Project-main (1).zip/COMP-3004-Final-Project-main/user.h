#ifndef USER_H
#define USER_H


class User
{
public:
    User();
};

#endif // USER_H
