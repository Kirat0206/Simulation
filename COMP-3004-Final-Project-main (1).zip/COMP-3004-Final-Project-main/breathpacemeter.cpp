#include "breathpacemeter.h"

BreathPaceMeter::BreathPaceMeter()
{

}

