#ifndef COHERENCELED_H
#define COHERENCELED_H


class CoherenceLED
{
public:
    CoherenceLED();
};

#endif // COHERENCELED_H
