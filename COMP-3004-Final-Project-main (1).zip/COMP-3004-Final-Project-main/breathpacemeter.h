#ifndef BREATHPACEMETER_H
#define BREATHPACEMETER_H


class BreathPaceMeter
{
public:
    BreathPaceMeter();
};

#endif // BREATHPACEMETER_H
